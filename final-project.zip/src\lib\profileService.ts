import type {
  UserProfile,
  PatientRecord,
  PrivacySettings,
  NotificationItem,
} from '../context/AuthContext';

export interface ProfileRow {
  id: string;
  email: string;
  phone: string;
  patient_record: PatientRecord;
  privacy_settings: PrivacySettings;
  notifications: NotificationItem[];
  onboarding_complete: boolean;
}

const DEFAULT_PRIVACY_SETTINGS: PrivacySettings = {
  showVitals: true,
  showConditions: true,
  showAllergies: true,
  showMedications: true,
  showContacts: true,
};

const getToken = () => localStorage.getItem('token');

export const createEmptyPatientRecord = (userId: string): PatientRecord => ({
  name: '',
  age: '',
  gender: '',
  bloodGroup: '',
  height: '',
  weight: '',
  photo: '',
  conditions: [],
  allergies: [],
  medications: [],
  contacts: [],
  documents: [],
  qrId: `mqr-${userId.slice(0, 8)}`,
});

export const fetchProfile = async (userId: string): Promise<UserProfile | null> => {
  const token = getToken();
  if (!token) {
    return null;
  }

  try {
    const response = await fetch('/api/auth/me', {
      headers: {
        'Authorization': `Bearer ${token}`
      }
    });
    
    if (!response.ok) {
      if (response.status === 401 || response.status === 403) {
        localStorage.removeItem('token');
      }
      return null;
    }
    
    const data = await response.json();
    if (data.success && data.user) {
      return {
        email: data.user.email || '',
        phone: data.user.phone || '',
        patientRecord: data.user.patientRecord || createEmptyPatientRecord(userId),
        privacySettings: data.user.privacySettings || DEFAULT_PRIVACY_SETTINGS,
        notifications: data.user.notifications || [],
      };
    }
    return null;
  } catch (err: any) {
    console.error('Failed to fetch profile from MySQL API:', err.message);
    return null;
  }
};

export const upsertProfile = async (
  userId: string,
  _email: string,
  profile: UserProfile,
  onboardingComplete?: boolean
): Promise<boolean> => {
  const token = getToken();
  if (!token) {
    return false;
  }

  try {
    const response = await fetch('/api/profiles/me', {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      },
      body: JSON.stringify({
        patientRecord: profile.patientRecord,
        privacySettings: profile.privacySettings,
        phone: profile.phone
      })
    });

    if (!response.ok) {
      return false;
    }

    if (onboardingComplete !== undefined) {
      if (onboardingComplete) {
        await setOnboardingComplete(userId);
      }
    }
    return true;
  } catch (err: any) {
    console.error('Failed to save profile to MySQL API:', err.message);
    return false;
  }
};

export const getOnboardingComplete = async (_userId: string): Promise<boolean> => {
  const token = getToken();
  if (!token) {
    return false;
  }

  try {
    const response = await fetch('/api/profiles/onboarding', {
      headers: {
        'Authorization': `Bearer ${token}`
      }
    });
    if (response.ok) {
      const data = await response.json();
      return Boolean(data.onboardingComplete);
    }
    return false;
  } catch (err: any) {
    console.error('Failed to read onboarding from MySQL API:', err.message);
    return false;
  }
};

export const setOnboardingComplete = async (_userId: string): Promise<void> => {
  const token = getToken();
  if (!token) {
    return;
  }

  try {
    await fetch('/api/profiles/onboarding', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${token}`
      }
    });
  } catch (err: any) {
    console.error('Failed to update onboarding in MySQL API:', err.message);
  }
};
