import express from 'express';
import cors from 'cors';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import mysql from 'mysql2/promise';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import nodemailer from 'nodemailer';

// Load environment variables
dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const DB_PATH = path.join(__dirname, 'db.json');

const app = express();
const PORT = 5000;
const JWT_SECRET = process.env.JWT_SECRET || 'mediqr_local_secret_key_123456';

app.use(cors());
app.use(express.json({ limit: '50mb' }));

const DEFAULT_PATIENT_RECORD = {
  name: "David Miller",
  age: "37",
  gender: "Male",
  bloodGroup: "A+",
  height: "182",
  weight: "78",
  photo: "",
  conditions: [
    { name: "Type-2 Diabetes", severity: "Moderate", notes: "Managed with Metformin" },
    { name: "Mild Hypertension", severity: "Mild", notes: "Regular monitoring" }
  ],
  allergies: [
    { name: "Penicillin", severity: "Severe", notes: "Reaction: Anaphylaxis risk" },
    { name: "Peanuts", severity: "Severe", notes: "Avoid all exposure" }
  ],
  medications: [
    { name: "Metformin", dosage: "500mg", frequency: "Twice daily", purpose: "Diabetes management" },
    { name: "Lisinopril", dosage: "10mg", frequency: "Once daily", purpose: "Blood pressure" }
  ],
  contacts: [
    { name: "Sarah Miller", relationship: "Spouse", phone: "+1 (555) 019-2835" },
    { name: "Dr. Arthur Pendelton", relationship: "Primary Physician", phone: "+1 (555) 489-1029" }
  ],
  documents: [
    { id: "doc-1", name: "Blood Chemistry Panel.pdf", date: "2026-04-12", size: "1.2 MB", category: "Lab Report" },
    { id: "doc-2", name: "Chest X-Ray Digital.png", date: "2026-03-20", size: "4.5 MB", category: "Imaging" }
  ],
  qrId: "mqr-david-8823"
};

const DEFAULT_PRIVACY_SETTINGS = {
  showVitals: true,
  showConditions: true,
  showAllergies: true,
  showMedications: true,
  showContacts: true
};

// --- MySQL Setup and Database Query Helper Functions ---
let mysqlPool = null;
let isMysqlConfigured = false;

const initMysql = async () => {
  if (!process.env.DB_HOST) {
    console.warn('MySQL environment variables not set in .env. MySQL integration is disabled.');
    return;
  }
  
  try {
    console.log(`Attempting to connect to MySQL on ${process.env.DB_HOST}:${process.env.DB_PORT || 3306}...`);
    // 1. Create a temporary connection to ensure the database exists
    const tempConnection = await mysql.createConnection({
      host: process.env.DB_HOST,
      user: process.env.DB_USER || 'root',
      password: process.env.DB_PASSWORD || '',
      port: parseInt(process.env.DB_PORT || '3306', 10)
    });
    
    await tempConnection.query(`CREATE DATABASE IF NOT EXISTS \`${process.env.DB_NAME || 'mediqr'}\``);
    await tempConnection.end();
    
    // 2. Initialize the main connection pool
    mysqlPool = mysql.createPool({
      host: process.env.DB_HOST,
      user: process.env.DB_USER || 'root',
      password: process.env.DB_PASSWORD || '',
      database: process.env.DB_NAME || 'mediqr',
      port: parseInt(process.env.DB_PORT || '3306', 10),
      waitForConnections: true,
      connectionLimit: 10,
      queueLimit: 0
    });
    
    isMysqlConfigured = true;
    console.log('MySQL Connection Pool created successfully.');
    
    // 3. Verify/create tables
    const connection = await mysqlPool.getConnection();
    
    // Users Table
    await connection.query(`
      CREATE TABLE IF NOT EXISTS users (
        id VARCHAR(255) PRIMARY KEY,
        email VARCHAR(255) UNIQUE NOT NULL,
        password_hash VARCHAR(255) NOT NULL,
        is_verified BOOLEAN DEFAULT FALSE,
        verification_token VARCHAR(255) DEFAULT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `);
    
    // Profiles Table
    await connection.query(`
      CREATE TABLE IF NOT EXISTS profiles (
        id VARCHAR(255) PRIMARY KEY,
        email VARCHAR(255) NOT NULL,
        phone VARCHAR(50) DEFAULT '',
        patient_record JSON NOT NULL,
        privacy_settings JSON NOT NULL,
        notifications JSON NOT NULL,
        onboarding_complete BOOLEAN NOT NULL DEFAULT FALSE,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
      )
    `);
    console.log('MySQL users and profiles tables verified/created successfully.');
    connection.release();
  } catch (err) {
    console.error('MySQL database initialization failed:', err.message);
    isMysqlConfigured = false;
  }
};

const parseJsonField = (field) => {
  if (typeof field === 'string') {
    try {
      return JSON.parse(field);
    } catch {
      return {};
    }
  }
  return field || {};
};

const getProfileFromMysqlByQrId = async (qrId) => {
  if (!isMysqlConfigured || !mysqlPool) return null;
  try {
    const [rows] = await mysqlPool.query(
      `SELECT * FROM profiles WHERE JSON_UNQUOTE(JSON_EXTRACT(patient_record, '$.qrId')) = ? LIMIT 1`,
      [qrId]
    );
    if (rows.length === 0) return null;
    return rows[0];
  } catch (err) {
    console.error(`Error querying MySQL by qrId (${qrId}):`, err.message);
    return null;
  }
};

const updateProfileInMysqlByQrId = async (qrId, patientRecord, privacySettings, email) => {
  if (!isMysqlConfigured || !mysqlPool) return null;
  try {
    const targetEmail = (email || patientRecord.email || '').trim().toLowerCase();
    
    // Find existing profile in MySQL (by QR ID or by email)
    let [rows] = await mysqlPool.query(
      `SELECT * FROM profiles WHERE JSON_UNQUOTE(JSON_EXTRACT(patient_record, '$.qrId')) = ? LIMIT 1`,
      [qrId]
    );
    
    if (rows.length === 0 && targetEmail) {
      const [emailRows] = await mysqlPool.query(
        `SELECT * FROM profiles WHERE email = ? LIMIT 1`,
        [targetEmail]
      );
      rows = emailRows;
    }
    
    const recordJson = JSON.stringify(patientRecord);
    const privacyJson = JSON.stringify(privacySettings);
    
    if (rows.length > 0) {
      const existing = rows[0];
      await mysqlPool.query(
        `UPDATE profiles SET patient_record = ?, privacy_settings = ?, email = ?, phone = ? WHERE id = ?`,
        [recordJson, privacyJson, targetEmail, patientRecord.phone || existing.phone || '', existing.id]
      );
      console.log(`Successfully updated MySQL profile for QR ID: ${qrId}`);
      return {
        patient_record: patientRecord,
        privacy_settings: privacySettings
      };
    } else {
      // Create new profile record
      const id = `local-mysql-${Date.now()}`;
      const notificationsJson = JSON.stringify([]);
      await mysqlPool.query(
        `INSERT INTO profiles (id, email, phone, patient_record, privacy_settings, notifications) VALUES (?, ?, ?, ?, ?, ?)`,
        [id, targetEmail, patientRecord.phone || '', recordJson, privacyJson, notificationsJson]
      );
      console.log(`Successfully created MySQL profile for QR ID: ${qrId}`);
      return {
        patient_record: patientRecord,
        privacy_settings: privacySettings
      };
    }
  } catch (err) {
    console.error(`Error updating MySQL profile by qrId (${qrId}):`, err.message);
    return null;
  }
};

// --- Seed database file (local fallback) ---
const initDb = () => {
  if (!fs.existsSync(DB_PATH)) {
    const initialDb = {
      [DEFAULT_PATIENT_RECORD.qrId]: {
        patientRecord: DEFAULT_PATIENT_RECORD,
        privacySettings: DEFAULT_PRIVACY_SETTINGS
      }
    };
    fs.writeFileSync(DB_PATH, JSON.stringify(initialDb, null, 2), 'utf8');
  }
};

const getDb = () => {
  try {
    initDb();
    const data = fs.readFileSync(DB_PATH, 'utf8');
    return JSON.parse(data);
  } catch (err) {
    console.error('Error reading database file', err);
    return {};
  }
};

const saveDb = (db) => {
  try {
    fs.writeFileSync(DB_PATH, JSON.stringify(db, null, 2), 'utf8');
  } catch (err) {
    console.error('Error writing to database file', err);
  }
};

// --- Nodemailer SMTP Setup & Helper ---
const smtpUser = process.env.SMTP_USER || '';
const smtpPass = process.env.SMTP_PASS || '';

let mailTransporter = null;
if (smtpUser && smtpPass) {
  mailTransporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
      user: smtpUser,
      pass: smtpPass
    }
  });
  console.log('Nodemailer SMTP Transporter initialized using Gmail.');
} else {
  console.warn('Gmail SMTP credentials missing. Verification links will be logged directly to the server terminal console.');
}

const sendVerificationEmail = async (email, token) => {
  const verificationUrl = `http://localhost:5000/api/auth/verify?token=${token}`;
  
  // Always log verification link to the console for a smooth local developer setup
  console.log(`\n======================================================================`);
  console.log(`[VERIFICATION EMAIL PENDING FOR: ${email}]`);
  console.log(`Verification URL: ${verificationUrl}`);
  console.log(`======================================================================\n`);
  
  if (mailTransporter) {
    try {
      await mailTransporter.sendMail({
        from: `"MediQR" <${smtpUser}>`,
        to: email,
        subject: 'Verify your MediQR Account',
        html: `
          <div style="font-family: Arial, sans-serif; max-width: 600px; margin: auto; padding: 25px; border: 1px solid #e2e8f0; border-radius: 16px; background-color: #ffffff; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.05);">
            <div style="text-align: center; margin-bottom: 20px;">
              <h2 style="color: #6200ee; font-size: 24px; margin-bottom: 5px;">Verify Your Email Address</h2>
              <p style="color: #64748b; font-size: 14px; margin-top: 0;">Secure health identity at your fingertips</p>
            </div>
            <p style="color: #334155; font-size: 16px; line-height: 1.6;">Thank you for registering with MediQR! Please verify your account to unlock full features, customize your patient record, and setup your medical emergency QR code profile.</p>
            <div style="text-align: center; margin: 35px 0;">
              <a href="${verificationUrl}" style="background-color: #6200ee; color: #ffffff; padding: 12px 30px; text-decoration: none; border-radius: 9999px; font-weight: bold; font-size: 16px; display: inline-block; box-shadow: 0 4px 6px rgba(98,0,238,0.2);">Verify My Email</a>
            </div>
            <p style="color: #64748b; font-size: 14px; line-height: 1.5; margin-top: 30px;">If the button above does not work, please copy and paste the following web address into your browser:</p>
            <p style="word-break: break-all; color: #6200ee; font-size: 13px; font-family: monospace; background-color: #f8fafc; padding: 10px; border-radius: 8px; border: 1px solid #e2e8f0;"><a href="${verificationUrl}">${verificationUrl}</a></p>
            <hr style="border: 0; border-top: 1px solid #e2e8f0; margin-top: 40px; margin-bottom: 20px;" />
            <p style="font-size: 11px; color: #94a3b8; text-align: center;">You received this email because you signed up on MediQR. If you did not make this request, you can safely ignore this email.</p>
          </div>
        `
      });
      console.log(`Verification email sent successfully via SMTP to: ${email}`);
    } catch (err) {
      console.error(`Failed to send email via SMTP to ${email}:`, err.message);
    }
  }
};

// --- Authentication Middleware ---
const authenticateToken = (req, res, next) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1]; // Bearer <token>
  
  if (!token) {
    return res.status(401).json({ error: 'Authentication token required' });
  }
  
  jwt.verify(token, JWT_SECRET, (err, decoded) => {
    if (err) {
      return res.status(403).json({ error: 'Invalid or expired authentication token' });
    }
    req.user = decoded;
    next();
  });
};

// --- Custom Authentication Endpoints ---

// 1. SIGNUP
app.post('/api/auth/signup', async (req, res) => {
  const { email, password } = req.body;
  if (!email || !password) {
    return res.status(400).json({ error: 'Email and password are required' });
  }
  
  const cleanEmail = email.trim().toLowerCase();
  if (!isMysqlConfigured || !mysqlPool) {
    return res.status(500).json({ error: 'MySQL database is not configured/running.' });
  }
  
  try {
    const [existingUsers] = await mysqlPool.query('SELECT * FROM users WHERE email = ?', [cleanEmail]);
    if (existingUsers.length > 0) {
      return res.status(400).json({ error: 'An account with this email already exists.' });
    }
    
    const userId = `u-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
    const passwordHash = await bcrypt.hash(password, 10);
    const verificationToken = `vt-${Math.random().toString(36).substr(2, 15)}${Math.random().toString(36).substr(2, 15)}`;
    
    // Insert User
    await mysqlPool.query(
      'INSERT INTO users (id, email, password_hash, is_verified, verification_token) VALUES (?, ?, ?, ?, ?)',
      [userId, cleanEmail, passwordHash, false, verificationToken]
    );
    
    // Initialize corresponding Profile
    const qrId = `mqr-${userId.slice(0, 8)}`;
    const defaultRecord = {
      name: "",
      age: "",
      gender: "",
      bloodGroup: "",
      height: "",
      weight: "",
      photo: "",
      conditions: [],
      allergies: [],
      medications: [],
      contacts: [],
      documents: [],
      qrId: qrId,
      email: cleanEmail
    };
    
    await mysqlPool.query(
      'INSERT INTO profiles (id, email, phone, patient_record, privacy_settings, notifications) VALUES (?, ?, ?, ?, ?, ?)',
      [userId, cleanEmail, '', JSON.stringify(defaultRecord), JSON.stringify(DEFAULT_PRIVACY_SETTINGS), JSON.stringify([])]
    );
    
    // Trigger verification email/link
    await sendVerificationEmail(cleanEmail, verificationToken);
    
    res.status(200).json({ success: true, message: 'Registration successful! Verification email sent.' });
  } catch (err) {
    console.error('Registration API error:', err);
    res.status(500).json({ error: 'Server error during account registration' });
  }
});

// 2. LOGIN
app.post('/api/auth/login', async (req, res) => {
  const { email, password } = req.body;
  if (!email || !password) {
    return res.status(400).json({ error: 'Email and password are required' });
  }
  
  const cleanEmail = email.trim().toLowerCase();
  if (!isMysqlConfigured || !mysqlPool) {
    return res.status(500).json({ error: 'MySQL database is not configured/running.' });
  }
  
  try {
    const [users] = await mysqlPool.query('SELECT * FROM users WHERE email = ?', [cleanEmail]);
    if (users.length === 0) {
      return res.status(400).json({ error: 'Invalid email or password.' });
    }
    
    const user = users[0];
    const match = await bcrypt.compare(password, user.password_hash);
    if (!match) {
      return res.status(400).json({ error: 'Invalid email or password.' });
    }
    
    if (!user.is_verified) {
      // Re-trigger/resend verification email
      let token = user.verification_token;
      if (!token) {
        token = `vt-${Math.random().toString(36).substr(2, 15)}${Math.random().toString(36).substr(2, 15)}`;
        await mysqlPool.query('UPDATE users SET verification_token = ? WHERE id = ?', [token, user.id]);
      }
      await sendVerificationEmail(user.email, token);
      return res.status(401).json({ error: 'EMAIL_NOT_VERIFIED' });
    }
    
    // Generate session JWT
    const token = jwt.sign({ id: user.id, email: user.email }, JWT_SECRET, { expiresIn: '7d' });
    
    // Get profile
    const [profiles] = await mysqlPool.query('SELECT * FROM profiles WHERE id = ?', [user.id]);
    const profile = profiles[0] || {};
    
    res.status(200).json({
      success: true,
      token,
      user: {
        id: user.id,
        email: user.email,
        phone: profile.phone || '',
        patientRecord: parseJsonField(profile.patient_record),
        privacySettings: parseJsonField(profile.privacy_settings) || DEFAULT_PRIVACY_SETTINGS,
        notifications: parseJsonField(profile.notifications) || []
      }
    });
  } catch (err) {
    console.error('Login API error:', err);
    res.status(500).json({ error: 'Server error during login authentication' });
  }
});

// 3. EMAIL VERIFICATION REDIRECT
app.get('/api/auth/verify', async (req, res) => {
  const { token } = req.query;
  if (!token) {
    return res.status(400).send('<div style="font-family:sans-serif;text-align:center;padding:50px;"><h1>Error</h1><p>Verification token is missing.</p></div>');
  }
  
  if (!isMysqlConfigured || !mysqlPool) {
    return res.status(500).send('<div style="font-family:sans-serif;text-align:center;padding:50px;"><h1>Error</h1><p>MySQL database not connected.</p></div>');
  }
  
  try {
    const [users] = await mysqlPool.query('SELECT * FROM users WHERE verification_token = ?', [token]);
    if (users.length === 0) {
      return res.status(400).send('<div style="font-family:sans-serif;text-align:center;padding:50px;"><h1>Invalid Token</h1><p>The verification link has expired or is invalid.</p></div>');
    }
    
    const user = users[0];
    await mysqlPool.query('UPDATE users SET is_verified = true, verification_token = NULL WHERE id = ?', [user.id]);
    
    const frontendUrl = process.env.FRONTEND_URL || 'http://localhost:5173';
    res.redirect(`${frontendUrl}/login?verified=true`);
  } catch (err) {
    console.error('Email verification error:', err);
    res.status(500).send('<div style="font-family:sans-serif;text-align:center;padding:50px;"><h1>Error</h1><p>Server error occurred during verification.</p></div>');
  }
});

// 4. RESEND VERIFICATION
app.post('/api/auth/resend', async (req, res) => {
  const { email } = req.body;
  if (!email) {
    return res.status(400).json({ error: 'Email address is required' });
  }
  
  const cleanEmail = email.trim().toLowerCase();
  if (!isMysqlConfigured || !mysqlPool) {
    return res.status(500).json({ error: 'MySQL database is not configured.' });
  }
  
  try {
    const [users] = await mysqlPool.query('SELECT * FROM users WHERE email = ?', [cleanEmail]);
    if (users.length === 0) {
      return res.status(404).json({ error: 'No account found with this email' });
    }
    
    const user = users[0];
    if (user.is_verified) {
      return res.status(400).json({ error: 'Account is already verified. Please sign in.' });
    }
    
    let token = user.verification_token;
    if (!token) {
      token = `vt-${Math.random().toString(36).substr(2, 15)}${Math.random().toString(36).substr(2, 15)}`;
      await mysqlPool.query('UPDATE users SET verification_token = ? WHERE id = ?', [token, user.id]);
    }
    
    await sendVerificationEmail(cleanEmail, token);
    res.status(200).json({ success: true, message: 'Verification link resent.' });
  } catch (err) {
    console.error('Resend verification link error:', err);
    res.status(500).json({ error: 'Server error resending verification' });
  }
});

// 4.5. CHECK VERIFICATION STATUS
app.get('/api/auth/status', async (req, res) => {
  const { email } = req.query;
  if (!email) {
    return res.status(400).json({ error: 'Email is required' });
  }
  
  const cleanEmail = email.trim().toLowerCase();
  if (!isMysqlConfigured || !mysqlPool) {
    return res.status(500).json({ error: 'MySQL database is not configured.' });
  }
  
  try {
    const [users] = await mysqlPool.query('SELECT is_verified FROM users WHERE email = ?', [cleanEmail]);
    if (users.length === 0) {
      return res.status(404).json({ error: 'User not found' });
    }
    
    res.status(200).json({ isVerified: Boolean(users[0].is_verified) });
  } catch (err) {
    console.error('Check verification status error:', err);
    res.status(500).json({ error: 'Database error checking verification status' });
  }
});

// 5. GET LOGGED IN USER
app.get('/api/auth/me', authenticateToken, async (req, res) => {
  if (!isMysqlConfigured || !mysqlPool) {
    return res.status(500).json({ error: 'MySQL database not configured.' });
  }
  
  try {
    const [profiles] = await mysqlPool.query('SELECT * FROM profiles WHERE id = ?', [req.user.id]);
    if (profiles.length === 0) {
      return res.status(404).json({ error: 'Profile not found' });
    }
    
    const profile = profiles[0];
    res.status(200).json({
      success: true,
      user: {
        id: req.user.id,
        email: req.user.email,
        phone: profile.phone || '',
        patientRecord: parseJsonField(profile.patient_record),
        privacySettings: parseJsonField(profile.privacy_settings) || DEFAULT_PRIVACY_SETTINGS,
        notifications: parseJsonField(profile.notifications) || []
      }
    });
  } catch (err) {
    console.error('Fetch me API error:', err);
    res.status(500).json({ error: 'Server error loading profile' });
  }
});

// 6. UPDATE PROFILE
app.put('/api/profiles/me', authenticateToken, async (req, res) => {
  const { patientRecord, privacySettings, phone } = req.body;
  if (!patientRecord || !privacySettings) {
    return res.status(400).json({ error: 'Missing patientRecord or privacySettings' });
  }
  
  if (!isMysqlConfigured || !mysqlPool) {
    return res.status(500).json({ error: 'MySQL database not configured.' });
  }
  
  try {
    const recordJson = JSON.stringify(patientRecord);
    const privacyJson = JSON.stringify(privacySettings);
    
    await mysqlPool.query(
      `UPDATE profiles SET patient_record = ?, privacy_settings = ?, phone = ? WHERE id = ?`,
      [recordJson, privacyJson, phone || patientRecord.phone || '', req.user.id]
    );
    
    res.status(200).json({
      success: true,
      data: {
        patientRecord,
        privacySettings
      }
    });
  } catch (err) {
    console.error('Update profile API error:', err);
    res.status(500).json({ error: 'Server error updating profile' });
  }
});

// 7. GET ONBOARDING STATUS
app.get('/api/profiles/onboarding', authenticateToken, async (req, res) => {
  if (!isMysqlConfigured || !mysqlPool) {
    return res.status(500).json({ error: 'MySQL database not configured.' });
  }
  
  try {
    const [profiles] = await mysqlPool.query('SELECT onboarding_complete FROM profiles WHERE id = ?', [req.user.id]);
    if (profiles.length === 0) {
      return res.status(200).json({ onboardingComplete: false });
    }
    res.status(200).json({ onboardingComplete: Boolean(profiles[0].onboarding_complete) });
  } catch (err) {
    console.error('Get onboarding Complete error:', err);
    res.status(500).json({ error: 'Server error checking onboarding status' });
  }
});

// 8. UPDATE ONBOARDING COMPLETED
app.post('/api/profiles/onboarding', authenticateToken, async (req, res) => {
  if (!isMysqlConfigured || !mysqlPool) {
    return res.status(500).json({ error: 'MySQL database not configured.' });
  }
  
  try {
    await mysqlPool.query('UPDATE profiles SET onboarding_complete = true WHERE id = ?', [req.user.id]);
    res.status(200).json({ success: true });
  } catch (err) {
    console.error('Update onboarding Complete error:', err);
    res.status(500).json({ error: 'Server error completing onboarding' });
  }
});

// --- Patient Record Endpoints (Public Access / Scanning) ---
app.get('/api/records/:qrId', async (req, res) => {
  const { qrId } = req.params;

  // 1. Try MySQL first
  if (isMysqlConfigured && mysqlPool) {
    try {
      const mysqlData = await getProfileFromMysqlByQrId(qrId);
      if (mysqlData) {
        return res.status(200).json({
          patientRecord: parseJsonField(mysqlData.patient_record),
          privacySettings: parseJsonField(mysqlData.privacy_settings) || DEFAULT_PRIVACY_SETTINGS
        });
      }
    } catch (err) {
      console.error(`MySQL error on GET /api/records/${qrId}:`, err.message);
    }
  }

  // 2. Fallback to local db.json
  const db = getDb();
  if (db[qrId]) {
    res.status(200).json(db[qrId]);
  } else {
    // If not found in db.json, check if we should return mock data to prevent errors during demo
    if (qrId === 'mq-784512' || qrId === 'mqr-david-8823') {
      const mockRecord = DEFAULT_PATIENT_RECORD.qrId === qrId ? DEFAULT_PATIENT_RECORD : { ...DEFAULT_PATIENT_RECORD, qrId };
      res.status(200).json({
        patientRecord: mockRecord,
        privacySettings: DEFAULT_PRIVACY_SETTINGS
      });
    } else {
      res.status(404).json({ error: 'Patient record not found' });
    }
  }
});

app.post('/api/records/:qrId', async (req, res) => {
  const { qrId } = req.params;
  const { patientRecord, privacySettings } = req.body;
  if (!patientRecord || !privacySettings) {
    return res.status(400).json({ error: 'Missing patientRecord or privacySettings in payload' });
  }

  let mysqlSuccess = false;
  let mysqlResult = null;

  // 1. Save to MySQL
  if (isMysqlConfigured && mysqlPool) {
    try {
      const email = patientRecord.email || '';
      mysqlResult = await updateProfileInMysqlByQrId(qrId, patientRecord, privacySettings, email);
      if (mysqlResult) {
        mysqlSuccess = true;
      }
    } catch (err) {
      console.error(`MySQL error on POST /api/records/${qrId}:`, err.message);
    }
  }

  // 2. Save to local db.json (fallback or parallel)
  const db = getDb();
  db[qrId] = { patientRecord, privacySettings };
  saveDb(db);

  if (mysqlSuccess && mysqlResult) {
    return res.status(200).json({
      success: true,
      source: 'mysql',
      data: {
        patientRecord: mysqlResult.patient_record,
        privacySettings: mysqlResult.privacy_settings
      }
    });
  }

  res.status(200).json({ success: true, source: 'local_json', data: db[qrId] });
});

// Start Express server
app.listen(PORT, async () => {
  console.log(`Backend server running on http://localhost:${PORT}`);
  // Initialize MySQL connection and tables asynchronously
  await initMysql();
});
