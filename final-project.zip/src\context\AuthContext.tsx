import React, { createContext, useContext, useState, useEffect, useRef } from 'react';
import {
  upsertProfile,
  createEmptyPatientRecord,
  getOnboardingComplete,
  setOnboardingComplete,
} from '../lib/profileService';

export interface ConditionAllergyItem {
  name: string;
  severity: 'Mild' | 'Moderate' | 'Severe' | string;
  notes?: string;
}

export interface Medication {
  name: string;
  dosage: string;
  frequency: string;
  purpose?: string;
}

export interface EmergencyContact {
  name: string;
  relationship: string;
  phone: string;
}

export interface MedicalDocument {
  id: string;
  name: string;
  date: string;
  size: string;
  category: string;
}

export interface NotificationItem {
  id: number;
  title: string;
  message: string;
  time: string;
  unread: boolean;
}

export interface PrivacySettings {
  showVitals: boolean;
  showConditions: boolean;
  showAllergies: boolean;
  showMedications: boolean;
  showContacts: boolean;
}

export interface PatientRecord {
  name: string;
  age: string;
  gender: string;
  bloodGroup: string;
  height: string;
  weight: string;
  photo: string;
  conditions: ConditionAllergyItem[];
  allergies: ConditionAllergyItem[];
  medications: Medication[];
  contacts: EmergencyContact[];
  documents: MedicalDocument[];
  qrId: string;
}

export interface UserProfile {
  email: string;
  phone: string;
  patientRecord: PatientRecord;
  privacySettings: PrivacySettings;
  notifications: NotificationItem[];
}

export interface AuthUser {
  uid: string;
  email: string;
}

interface AuthContextType {
  isAuthenticated: boolean;
  authLoading: boolean;
  onboardingComplete: boolean;
  user: UserProfile | null;
  authUser: AuthUser | null;
  signUp: (email: string, password: string) => Promise<{ error: string | null }>;
  resendVerificationEmail: () => Promise<{ error: string | null }>;
  checkEmailVerificationStatus: () => Promise<boolean>;
  signIn: (email: string, password: string) => Promise<{ error: string | null }>;
  completeOnboarding: () => Promise<void>;
  logout: () => Promise<void>;
  updatePatientRecord: (record: Partial<PatientRecord>) => void;
  updatePrivacySettings: (settings: Partial<PrivacySettings>) => void;
  addMedication: (med: Medication) => void;
  removeMedication: (index: number) => void;
  addContact: (contact: EmergencyContact) => void;
  removeContact: (index: number) => void;
  addCondition: (cond: ConditionAllergyItem) => void;
  removeCondition: (name: string) => void;
  addAllergy: (allergy: ConditionAllergyItem) => void;
  removeAllergy: (name: string) => void;
  addDocument: (doc: Omit<MedicalDocument, 'id' | 'date'>) => void;
  removeDocument: (id: string) => void;
  markNotificationsAsRead: () => void;
  regenerateQrData: () => void;
}

const DEFAULT_PRIVACY_SETTINGS: PrivacySettings = {
  showVitals: true,
  showConditions: true,
  showAllergies: true,
  showMedications: true,
  showContacts: true,
};

const syncRecordToDb = async (qrId: string, record: PatientRecord, settings: PrivacySettings) => {
  if (!qrId) return;
  try {
    const response = await fetch(`/api/records/${qrId}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ patientRecord: record, privacySettings: settings }),
    });
    if (!response.ok) {
      console.error('Failed to sync record to backend');
    }
  } catch (err) {
    console.error('Error syncing record to backend API', err);
  }
};

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [authLoading, setAuthLoading] = useState(true);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [onboardingComplete, setOnboardingCompleteState] = useState(false);
  const [authUser, setAuthUser] = useState<AuthUser | null>(null);
  const [user, setUser] = useState<UserProfile | null>(null);
  
  // Track email pending verification locally to support checkEmailVerificationStatus()
  const [pendingVerificationEmail, setPendingVerificationEmail] = useState<string | null>(() => {
    return localStorage.getItem('pending_verification_email');
  });

  const shouldSyncRef = useRef(false);
  const profileSaveTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  // Handle automatic session verification on app load
  useEffect(() => {
    const initAuth = async () => {
      const token = localStorage.getItem('token');
      if (!token) {
        setAuthLoading(false);
        return;
      }

      try {
        const response = await fetch('/api/auth/me', {
          headers: {
            'Authorization': `Bearer ${token}`
          }
        });

        if (response.ok) {
          const data = await response.json();
          if (data.success && data.user) {
            const loggedUser: AuthUser = { uid: data.user.id, email: data.user.email };
            setAuthUser(loggedUser);
            setIsAuthenticated(true);
            
            setUser({
              email: data.user.email,
              phone: data.user.phone || '',
              patientRecord: data.user.patientRecord || createEmptyPatientRecord(data.user.id),
              privacySettings: data.user.privacySettings || DEFAULT_PRIVACY_SETTINGS,
              notifications: data.user.notifications || []
            });

            const completed = await getOnboardingComplete(data.user.id);
            setOnboardingCompleteState(completed);
          } else {
            localStorage.removeItem('token');
          }
        } else {
          localStorage.removeItem('token');
        }
      } catch (err) {
        console.error('Auto login check failed:', err);
      } finally {
        setAuthLoading(false);
      }
    };

    initAuth();
  }, []);

  // Save changes automatically to the database
  useEffect(() => {
    if (!user || !authUser) return;

    if (shouldSyncRef.current) {
      shouldSyncRef.current = false;
      if (typeof window !== 'undefined' && !window.location.pathname.startsWith('/emergency/')) {
        syncRecordToDb(user.patientRecord.qrId, user.patientRecord, user.privacySettings);
      }
    }

    if (profileSaveTimerRef.current) {
      clearTimeout(profileSaveTimerRef.current);
    }

    profileSaveTimerRef.current = setTimeout(() => {
      upsertProfile(authUser.uid, authUser.email || user.email, user);
    }, 800);

    return () => {
      if (profileSaveTimerRef.current) {
        clearTimeout(profileSaveTimerRef.current);
      }
    };
  }, [user, authUser]);

  const signUp = async (email: string, password: string): Promise<{ error: string | null }> => {
    try {
      const response = await fetch('/api/auth/signup', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: email.trim().toLowerCase(), password })
      });

      const data = await response.json();
      if (!response.ok) {
        return { error: data.error || 'Signup failed' };
      }

      // Store pending verification email
      const cleanEmail = email.trim().toLowerCase();
      setPendingVerificationEmail(cleanEmail);
      localStorage.setItem('pending_verification_email', cleanEmail);
      
      return { error: null };
    } catch (err: any) {
      return { error: err.message || 'Signup connection error' };
    }
  };

  const resendVerificationEmail = async (): Promise<{ error: string | null }> => {
    const targetEmail = pendingVerificationEmail;
    if (!targetEmail) {
      return { error: 'No verification session in progress' };
    }

    try {
      const response = await fetch('/api/auth/resend', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: targetEmail })
      });

      const data = await response.json();
      if (!response.ok) {
        return { error: data.error || 'Resend failed' };
      }

      return { error: null };
    } catch (err: any) {
      return { error: err.message || 'Resend link error' };
    }
  };

  const checkEmailVerificationStatus = async (): Promise<boolean> => {
    const targetEmail = pendingVerificationEmail;
    if (!targetEmail) return false;

    try {
      const response = await fetch(`/api/auth/status?email=${encodeURIComponent(targetEmail)}`);
      if (response.ok) {
        const data = await response.json();
        if (data.isVerified) {
          // Clear pending session since it is verified now
          setPendingVerificationEmail(null);
          localStorage.removeItem('pending_verification_email');
          return true;
        }
      }
      return false;
    } catch {
      return false;
    }
  };

  const signIn = async (email: string, password: string): Promise<{ error: string | null }> => {
    try {
      const response = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: email.trim().toLowerCase(), password })
      });

      const data = await response.json();
      if (!response.ok) {
        if (data.error === 'EMAIL_NOT_VERIFIED') {
          const cleanEmail = email.trim().toLowerCase();
          setPendingVerificationEmail(cleanEmail);
          localStorage.setItem('pending_verification_email', cleanEmail);
          return { error: 'EMAIL_NOT_VERIFIED' };
        }
        return { error: data.error || 'Invalid email or password' };
      }

      localStorage.setItem('token', data.token);
      
      const loggedUser: AuthUser = { uid: data.user.id, email: data.user.email };
      setAuthUser(loggedUser);
      setIsAuthenticated(true);
      
      setUser({
        email: data.user.email,
        phone: data.user.phone || '',
        patientRecord: data.user.patientRecord || createEmptyPatientRecord(data.user.id),
        privacySettings: data.user.privacySettings || DEFAULT_PRIVACY_SETTINGS,
        notifications: data.user.notifications || []
      });

      const completed = await getOnboardingComplete(data.user.id);
      setOnboardingCompleteState(completed);

      // Clear pending verification email on successful login
      setPendingVerificationEmail(null);
      localStorage.removeItem('pending_verification_email');

      return { error: null };
    } catch (err: any) {
      return { error: err.message || 'Sign in connection error' };
    }
  };

  const completeOnboarding = async () => {
    if (authUser) {
      await setOnboardingComplete(authUser.uid);
      setOnboardingCompleteState(true);
    }
  };

  const logout = async () => {
    localStorage.removeItem('token');
    localStorage.removeItem('pending_verification_email');
    setAuthUser(null);
    setIsAuthenticated(false);
    setUser(null);
    setOnboardingCompleteState(false);
    setPendingVerificationEmail(null);
  };

  const updatePatientRecord = (record: Partial<PatientRecord>) => {
    shouldSyncRef.current = true;
    setUser((prev) => {
      if (!prev) return null;
      return { ...prev, patientRecord: { ...prev.patientRecord, ...record } };
    });
  };

  const updatePrivacySettings = (settings: Partial<PrivacySettings>) => {
    shouldSyncRef.current = true;
    setUser((prev) => {
      if (!prev) return null;
      return { ...prev, privacySettings: { ...prev.privacySettings, ...settings } };
    });
  };

  const addMedication = (med: Medication) => {
    shouldSyncRef.current = true;
    setUser((prev) => {
      if (!prev) return null;
      return {
        ...prev,
        patientRecord: {
          ...prev.patientRecord,
          medications: [...prev.patientRecord.medications, med],
        },
      };
    });
  };

  const removeMedication = (index: number) => {
    shouldSyncRef.current = true;
    setUser((prev) => {
      if (!prev) return null;
      const medications = [...prev.patientRecord.medications];
      medications.splice(index, 1);
      return { ...prev, patientRecord: { ...prev.patientRecord, medications } };
    });
  };

  const addContact = (contact: EmergencyContact) => {
    shouldSyncRef.current = true;
    setUser((prev) => {
      if (!prev) return null;
      return {
        ...prev,
        patientRecord: {
          ...prev.patientRecord,
          contacts: [...prev.patientRecord.contacts, contact],
        },
      };
    });
  };

  const removeContact = (index: number) => {
    shouldSyncRef.current = true;
    setUser((prev) => {
      if (!prev) return null;
      const contacts = [...prev.patientRecord.contacts];
      contacts.splice(index, 1);
      return { ...prev, patientRecord: { ...prev.patientRecord, contacts } };
    });
  };

  const addCondition = (cond: ConditionAllergyItem) => {
    shouldSyncRef.current = true;
    setUser((prev) => {
      if (!prev) return null;
      if (prev.patientRecord.conditions.some((c) => c.name.toLowerCase() === cond.name.toLowerCase())) {
        return prev;
      }
      return {
        ...prev,
        patientRecord: {
          ...prev.patientRecord,
          conditions: [...prev.patientRecord.conditions, cond],
        },
      };
    });
  };

  const removeCondition = (name: string) => {
    shouldSyncRef.current = true;
    setUser((prev) => {
      if (!prev) return null;
      return {
        ...prev,
        patientRecord: {
          ...prev.patientRecord,
          conditions: prev.patientRecord.conditions.filter((c) => c.name !== name),
        },
      };
    });
  };

  const addAllergy = (allergy: ConditionAllergyItem) => {
    shouldSyncRef.current = true;
    setUser((prev) => {
      if (!prev) return null;
      if (prev.patientRecord.allergies.some((a) => a.name.toLowerCase() === allergy.name.toLowerCase())) {
        return prev;
      }
      return {
        ...prev,
        patientRecord: {
          ...prev.patientRecord,
          allergies: [...prev.patientRecord.allergies, allergy],
        },
      };
    });
  };

  const removeAllergy = (name: string) => {
    shouldSyncRef.current = true;
    setUser((prev) => {
      if (!prev) return null;
      return {
        ...prev,
        patientRecord: {
          ...prev.patientRecord,
          allergies: prev.patientRecord.allergies.filter((a) => a.name !== name),
        },
      };
    });
  };

  const addDocument = (doc: Omit<MedicalDocument, 'id' | 'date'>) => {
    shouldSyncRef.current = true;
    setUser((prev) => {
      if (!prev) return null;
      const newDoc: MedicalDocument = {
        ...doc,
        id: `doc-${Date.now()}`,
        date: new Date().toISOString().split('T')[0],
      };
      return {
        ...prev,
        patientRecord: {
          ...prev.patientRecord,
          documents: [newDoc, ...prev.patientRecord.documents],
        },
      };
    });
  };

  const removeDocument = (id: string) => {
    shouldSyncRef.current = true;
    setUser((prev) => {
      if (!prev) return null;
      return {
        ...prev,
        patientRecord: {
          ...prev.patientRecord,
          documents: prev.patientRecord.documents.filter((d) => d.id !== id),
        },
      };
    });
  };

  const markNotificationsAsRead = () => {
    setUser((prev) => {
      if (!prev) return null;
      return {
        ...prev,
        notifications: prev.notifications.map((n) => ({ ...n, unread: false })),
      };
    });
  };

  const regenerateQrData = () => {
    if (user?.patientRecord.qrId) {
      syncRecordToDb(user.patientRecord.qrId, user.patientRecord, user.privacySettings);
    }
  };

  return (
    <AuthContext.Provider
      value={{
        isAuthenticated,
        authLoading,
        onboardingComplete,
        user,
        authUser,
        signUp,
        resendVerificationEmail,
        checkEmailVerificationStatus,
        signIn,
        completeOnboarding,
        logout,
        updatePatientRecord,
        updatePrivacySettings,
        addMedication,
        removeMedication,
        addContact,
        removeContact,
        addCondition,
        removeCondition,
        addAllergy,
        removeAllergy,
        addDocument,
        removeDocument,
        markNotificationsAsRead,
        regenerateQrData,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
